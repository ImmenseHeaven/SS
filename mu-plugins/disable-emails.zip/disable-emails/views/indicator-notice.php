<?php
if (!defined('ABSPATH')) {
	exit;
}
?>

<div class="notice notice-error">
	<p><?php esc_html_e('Emails are disabled by the Disable Emails plugin.', 'disable-emails'); ?></p>
</div>
